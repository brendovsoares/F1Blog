document.getElementById("contactForm").addEventListener("submit", function(event) {
  alert("Mensagem enviada com sucesso!");
  event.preventDefault();
});
